package com.java2s.ide;
import junit.framework.Assert;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class TestApp1 {
 
  public void testPrintHelloWorld() {
    Assert.assertEquals(App.getHelloWorld(), "Hello World");
  }
}
