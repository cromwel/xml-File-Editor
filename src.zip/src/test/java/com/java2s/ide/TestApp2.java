package com.java2s.ide; 
import junit.framework.Assert;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
public class TestApp2 {

  public void testPrintHelloWorld2() {
    Assert.assertEquals(App.getHelloWorld2(), "Hello World my name is lindy");
  }
}
